
## Variables

## Int Float

Int 1,-1,0
Float 1.2132123123123 (unlimited precision)

## String
```python
'Hello' == "Hello" == """Hello"""
"Hello".capitalize()
"Hello".replace()
"Hello".isalpha()
"Hello".isdigit()
"a,b,c".split("s")
"{0} and {1}. {0} again.".format("Hi","Hello")
name = "Adrian"
lastname = "Eguez"
f"{name} {lastname}."
r"Raw"
```
## Boolean, None
hello_course = True
hello_course = False
int(True) ## 1
int(False) ## 0
str(True) ## "True"

aliens_found = None
