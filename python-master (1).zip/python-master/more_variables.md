# complex
The functions in this module accept integers, floating-point numbers or complex numbers as arguments.

# bytes

# bytearray

# tuple

tupla = (1,"2",True)

# set and frozenset

no_repetidos = set([1,2,3,3,3]) # [1,2,3]

# https://www.programiz.com/python-programming/set
