# Importar

## student.py

```python
class Student
    pass


class HighSchoolStudent
    pass
```

## main.py

```python

# import student
# estudiante = student.Student()
# from student import *
from student import Student, HighSchoolStudent

estudiante = Student()

```
