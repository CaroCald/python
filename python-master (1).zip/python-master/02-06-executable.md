# Executable

[LINK executable](https://www.pyinstaller.org/)

```
$ pip install pyinstaller
```

```
$ pyinstaller yourprogram.py
```

[LINK distributable](http://www.jrsoftware.org/isinfo.php)
