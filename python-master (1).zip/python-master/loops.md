```python
array = [1,2,3,4]

for number in array:
  print("Number {0}").append(number)
  
  
for index in range(10):
  print("Hello") # 10 times
  
for index in range(4,10):
  print("Hello") # 10 times
  
break (stop)
continue (stop this one and continue)

x = 0
while x < 10:
  print("X = {0}".format(x))
  x+=1
  
while True:
	print(f"Hello {x}")
	if x == 3:
	    break
	x+=1
```
