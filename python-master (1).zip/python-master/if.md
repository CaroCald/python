
```python
number = 5
if number == 5:
  print("Hi")
else:
  print("Hello")
  
  
if "Hi":
  print("Hi")
else:
  print("Hello")
  
  
if 0:
  print("Hi")
else:
  print("Hello")
  
if None:
  print("Hi")
else:
  print("Hello")
  
if number != 5:
  print("Hi")
else:
  print("Hello")
  
if not None:
  print("Hi")
else:
  print("Hello")
  
if True and False:
  print("Hi")
else:
  print("Hello")
  
if True or False:
  print("Hi")
else:
  print("Hello")
 
 
 "bigger" if 2 > 1 else "smaller"
```
